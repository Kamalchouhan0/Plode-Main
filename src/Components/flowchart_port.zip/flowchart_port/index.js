import React from "react";
import {
  Switch,
  Route,
  // Redirect
} from "react-router-dom";
import Port from "./Port";
import InputOutput from "./Input";
import Digital from "./Digital";
import FlowchartPage from "./FlowchartPage";
import InternalAccessories from "./InternalAccessories";
import ProgramSelection from "./programSelection";
import Header from "./Header";

function Flow(props) {
  return (
    <>
      <Switch>
        <Route exact path="/flow" component={ProgramSelection} />
        <Route
          exact
          path="/flow/InternalAccessories"
          component={InternalAccessories}
        />
        <Route exact path="/flow/selectports" component={Port} />
        <Route exact path="/flow/input-output" component={InputOutput} />
        <Route exact path="/flow/digital-analog" component={Digital} />
        <Route exact path="/flow/flowchart" component={FlowchartPage} />
      </Switch>
    </>
  );
}

export default Flow;
