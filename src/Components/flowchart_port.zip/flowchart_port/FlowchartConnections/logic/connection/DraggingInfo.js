
module.exports = {
  isDragging: false,
  draggingComponentOld: null,
  newComponentPort: null,
  setSidebarScroll: null,
  scrollingSidebar: false,
  sidebarOldOffset: 0,
}
